module.exports = {
    database: {
        host: 'customers.cp6hwkxv4ldn.us-east-2.rds.amazonaws.com',
        user: 'admin',
        password: '345834583458Gb',
        database: 'pokemonwi'
    }
};